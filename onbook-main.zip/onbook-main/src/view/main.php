<div class="container-text">
  <h1>Quem somos</h1>
  <p>
      Olá, Somos a Onbook!  
      Temos como desejo incentivar a leitura e a escrita através desta aplicação. Aproveite o nosso site. Let's write!
  </p>
</div>
<div class="container-img">
  <img class="svg-img" src="./assets/writer.svg">
</div>